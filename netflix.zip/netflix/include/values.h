/*
 * TODO: Nothing here yet. Should provide UNIX compatibility constants
 * comparable to those in limits.h and float.h.
 */
